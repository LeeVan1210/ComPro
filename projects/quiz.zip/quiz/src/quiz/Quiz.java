/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

/**
 *
 * @author Juan
 */
import java.util.Scanner;
public class Quiz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int rows;
        
        Scanner in = new Scanner(System.in);
        System.out.print("enter Number of Pattern: ");

        rows = in.nextInt();
        
        for(int a = rows; a >= 1; --a){
            for(int b = 1; b<= a; ++b){
                System.out.print("* ");
            }
            System.out.println(" ");
        }
        // TODO code application logic here
    }
    
}
