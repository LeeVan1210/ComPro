/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;
import java.util.Scanner;

/**
 *
 * @author Juan
 */
public class multiplicationTable {
    public static void main(String []args){
        
        int num = 9, i =1;
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Number to Multiply: ");
        num = input.nextInt();
        while(i<=10)
        {
            System.out.printf("%d * %d = %d \n", num, i, num * i);
            i++;
        }
    }
}
