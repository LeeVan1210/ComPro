/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

/**
 *
 * @author Juan
 */
public class fizzbuzz {
    public static void main(String[]args){
        
        int rows=100;
        
        for(int a = 1; a <=100; a++){
            if ((a%15)==0)
                System.out.println(a+" fuzzbuzz");
            else if ((a%7)==0)
                System.out.println(a+" buzz");
            else if ((a%3)==0)
                System.out.println(a+" fizz");
            else
                System.out.println(a);

    }
    
}
}
