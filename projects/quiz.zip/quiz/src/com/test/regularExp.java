/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;
// 
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;


/**
 *
 * @author Juan
 */
public class regularExp {
    public static void main(String[]args){
        
        Scanner content = new Scanner(System.in);
        String line;
        System.out.println("enter String: ");
        line = content.next();
        String pattern = "(.*)(\\d+)(.*)";
        
        Pattern r = Pattern.compile(pattern);
        
        Matcher m = r.matcher(line);
        if(m.find()){
            System.out.println("found value : "+ m.group(0));
            System.out.println("found value : "+ m.group(1));
            System.out.println("found value : "+ m.group(2));
        }
        else{
            System.out.println("NO MAtch");
        
    }
}
}