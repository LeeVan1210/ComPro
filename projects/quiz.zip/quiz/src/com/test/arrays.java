/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test;

/**
 *
 * @author Juan
 */
public class arrays {
    public static void main(String []args){
            // For-Each
//        String[] names = {"Joy","Mark","toto","Tata"};
//        for(String a:names){
//        System.out.println(a);
            // Multidimentional Array
          int[][] myNumbers = {{1,2,3,4},{5,6,7}};
          int x = myNumbers[0][2];
          System.out.println(x);
    }
}
