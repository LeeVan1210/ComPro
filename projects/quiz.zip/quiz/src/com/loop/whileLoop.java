/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.loop;
import static java.lang.System.in;
import java.util.Scanner;


/**
 *
 * @author Juan
 */
public class whileLoop {
    public static void main(String[]args){
        
        int n;
        int a,b,ans,bool;
         Scanner input = new Scanner(System.in);
         
         do{
             System.out.print("1 For Addition \n2 for Subtraction \n::");
             n = input.nextInt();
             Scanner num1 = new Scanner(System.in);
             Scanner num2 = new Scanner(System.in);
             
             switch(n){
                
                 case 1:
                     System.out.print("Enter First Number: ");
                     a = num1.nextInt();
                     System.out.print("Enter second Number: ");
                     b = num2.nextInt();
                     ans = b+a;
                     System.out.println("the Sum is :" + ans);
                     
                     break;
                     
                 case 2:
                     System.out.print("Enter First Number: ");
                     a = num1.nextInt();
                     System.out.print("Enter second Number: ");
                     b = num2.nextInt();
                     System.out.println(b-a);
                     break;       
             }
             Scanner in = new Scanner(System.in);
             System.out.print("new transaction? \n[1]YES/[0]NO \n:: ");
             bool = in.nextInt();

         }while(bool ==1);
          
        
    }
    
}
