/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.loop;

/**
 *
 * @author Juan
 */
public class throwException {
    static void checkAge(int age){
        if (age<18){
            throw new ArithmeticException("Access denied, must be above 18yrOld");
        }
        else{
            System.out.println("Access granted , Guwang naka ");
        }
    }
    
    public static void main(String[] args){
        checkAge(17); 
    }
    
}
