/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.loop;

/**
 *
 * @author Juan
 */
public class labay {
    public static void main(String []args){
        
        int a = 1000;
        int b = 100;
        
//        for (a = 0; a<10;a+=b){
//            
//            System.out.println(a);
//            
//        }
        while(a!=0){
            System.out.println(a);
            a-=b;
        }
        
                    System.out.println(0);

         
    }
    
}
