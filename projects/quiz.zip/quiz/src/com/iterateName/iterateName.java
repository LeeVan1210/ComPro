/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iterateName;
import java.util.Scanner;

/**
 *
 * @author Juan
 */
public class iterateName {

    /**
     *
     * @param args
     */
    public static void main (String[]args){
        int a ;
        a = 0;
        int bool;
        String name;
        
        Scanner in = new Scanner(System.in);
        
        
        do{
            System.out.print("enter name: ");
            Scanner input = new Scanner(System.in);
            name = input.next();
            System.out.println("your name is: " + name);
            System.out.print("would you like to continue? \n[1]YES/[0]NO \n:: ");
            bool = in.nextInt();
           
            
        }
        while(bool ==1);
    }
    
}
