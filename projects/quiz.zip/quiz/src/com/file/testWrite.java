/*
 * This program is Coded by BBTAM
 *   * 
 */
package com.file;
import static com.file.FileIO.fileName;
import java.util.Scanner;
import java.io.*;
import java.nio.file.*;


/**
 *
 * @author Juan
 */
public class testWrite {

//    static void writeFile(){
//        String fileWrite;
//        Scanner input = new Scanner(System.in);
//        Path filePath = Paths.get("C:\\Users\\Public\\Documents\\"+fileName+"tata.txt");
//        try{
//            System.out.println("content: ");
//            fileWrite = input.nextLine();
//            String content = fileWrite;
//            input.close();
//            byte[] bs = content.getBytes();
//            Path writtenPath = Files.write(filePath, bs);
//            System.out.println("content written in "+new String(Files.readAllBytes(filePath)));
//            
//        }catch(IOException e){
//            
//        }
//    }
//    
    
        public static int choice;
        public static String fileName, fileWrite;
        public static Scanner input = new Scanner(System.in);
        public static Scanner choicein = new Scanner(System.in);
        
        public static Path filePath = Paths.get("C:\\Users\\Public\\Documents\\"+fileName+"tata.txt");
        
    
    static void writeToCreatedFile(){
        try{
            System.out.println("content: ");
            fileWrite = input.nextLine();
            String content = fileWrite;
            input.close();
            byte[] bs = content.getBytes();
            Path writtenPath = Files.write(filePath, bs);
            System.out.println("content written in "+new String(Files.readAllBytes(writtenPath)));
            
        }catch(IOException e){
            System.out.println("niagi ko diri");
        }
        
}
  
    static void createFile(){
    

        System.out.println("Name: ");
        fileName = input.next();
        try{
            Path createFile = Files.createFile(filePath);
            System.out.println("File created "+ createFile);
            
            System.out.println("Write to file? [1]YES [2]NO ::");
            choice = choicein.nextInt();
            switch(choice){
                case 1: 
                writeToCreatedFile();

                break;
                case 2:
                break;
                    
            }
        }catch(IOException e){
            
        }
        
    }
    public static void main(String []args){
        
        createFile(); 
//            writeFile();
        
        
    }
    
}
