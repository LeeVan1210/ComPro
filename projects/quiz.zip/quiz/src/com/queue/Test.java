/*
 * This program is Coded by BBTAM
 *   * 
 */
package com.queue;

/**
 *
 * @author Juan
 */
public class Test {
    private final int patientPriority;
    private final String patientName;
    
    private final int patientId;
    
    public Test(int id, String name, int priority){
        this.patientName = name;
        this.patientPriority = priority;
        this.patientId = id;
    }
    public int getPriority(){
        return patientPriority;
    }
    public int getId(){
        return patientId;
    }
    public String getName(){
        return patientName;
    }
    
}

