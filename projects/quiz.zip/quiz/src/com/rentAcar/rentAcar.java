/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



package com.rentAcar;
import java.util.*;

/**
 *
 * @author Juan
 */
public class rentAcar {
    
    public static String carMade, carType, carName;
    public static int menu;
    public static Scanner carin = new Scanner(System.in);
    public static Scanner menuin = new Scanner(System.in);
    
    static void welcome(){
        System.out.println("Welcome to BBTAM car Rentals");
    }
    
    static void add(){
        System.out.print("Add Car Name: ");
        carName =  carin.next(); 
        
    }
    
    static void list(){
        ArrayList<String> list = new ArrayList<String>();
        list.add("Nissan");
        list.add("Toyota");
        list.add(carName);
        for(String x: list){
            System.out.println(x);
        }
    }
    
    public static void main(String[]args){
        
        welcome();
        do{
            System.out.println("[1]VIEW LIST /n[2]ADD");
            menu = menuin.nextInt();
            switch(menu){
                case 1:
                    list();
                    System.out.println("----------------------------------");
                    break;
                case 2:
                    add();
                    break;        
            }
            System.out.println("NEW TRANSACTION?");
        }
        
        while(true);
       }  
    } 
